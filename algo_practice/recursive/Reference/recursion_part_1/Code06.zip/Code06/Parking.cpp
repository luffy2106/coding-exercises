/* File: Parking.cpp
 * 
 * A program to simulate randomly parking along a stretch of curb
 * in order to find how many cars, on average, will fit.
 */

#include <iostream>
#include "random.h"
using namespace std;

/* The number of trials to run. */
const int NUM_TRIALS = 1000000;

/* The width of the curb. */
const double CURB_WIDTH = 100;

/* Simulates randomly parking cars, returning how many cars fit. */
int randomlyParkCars(double start, double stop);

int main() {
	int total = 0;
	for (int i = 0; i < NUM_TRIALS; i++) {
		total += randomlyParkCars(0.0, CURB_WIDTH);
	}

	cout << "Total cars parked: " << total << endl;
}

int randomlyParkCars(double start, double stop) {
	if (stop - start < 1.0) {
		return 0;
	} else {
		double x = randomReal(start, stop - 1.0);

		return 1 + randomlyParkCars(start, x) +
			       randomlyParkCars(x + 1.0, stop);
	}
}