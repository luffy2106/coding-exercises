/*
 * File: HanoiGraphics.cpp
 * -----------------------
 * This file implements the graphical Hanoi functions.
 */

#include <iostream>
#include <string>
#include "HanoiGraphics.h"
#include "error.h"
#include "graphics.h"
#include "vector.h"

/* Constants */

const int MAX_DISKS = 8;
const double DEFAULT_DELAY_TIME = 200;
const double DISK_HEIGHT_PIXELS = 12;
const double DISK_MAX_PIXELS = 140;
const double DISK_DELTA_PIXELS = 10;
const double FRAME_THICKNESS_PIXELS = 6;

const string COLOR_TABLE[] = {
   "Unused",
   "Red",
   "Yellow",
   "Green",
   "Cyan",
   "Blue",
   "Magenta",
   "Orange",
   "Gray"
};

/* Private state */

static int cSign;
static double frameThickness;
static double frameWidth;
static double frameHeight;
static double diskHeight;
static double diskMax;
static double diskDelta;
static double xBase;
static double yBase;
static double frameX[3];
static double delayTime = DEFAULT_DELAY_TIME;
static Vector< Vector<int> > towers;

/* Function prototypes */

static void computeGraphicsParameters(int n);
static void repaintWindow();
static void drawFrame();
static void drawDisk(int k, int tower, int level);

/*
 * Function: initHanoiGraphics
 * Usage: initHanoiGraphics(n);
 * ----------------------------
 * Initializes the graphics window and draws the starting
 * configuration for a Towers of Hanoi puzzle for n disks,
 * where n may not be larger than 8.
 */

void initHanoiGraphics(int n) {
   if (n > MAX_DISKS) error("Disk limit exceeded");
   initGraphics();
   computeGraphicsParameters((n < 4) ? 4 : n);
   towers.clear();
   for (int i = 0; i < 3; i++) {
      towers.add(Vector<int>());
   }
   for (int disk = n; disk > 0; disk--) {
      towers[0].add(disk);
   }
   repaintWindow();
}

/*
 * Function: moveSingleDisk
 * Usage: moveSingleDisk(char start, char finish);
 * -----------------------------------------------
 * Moves a single disk from the start tower to the finish
 * tower.  This method generates an error if the start tower
 * is empty or if the move violates the rules of the Hanoi
 * puzzle by placing a larger disk on top of a smaller one.
 */

void moveSingleDisk(char start, char finish) {
   int nDisks = towers[start - 'A'].size();
   if (nDisks == 0) error("The start tower is empty");
   int disk = towers[start - 'A'][nDisks - 1];
   towers[start - 'A'].removeAt(nDisks - 1);
   nDisks = towers[finish - 'A'].size();
   if (nDisks > 0 && disk > towers[finish - 'A'][nDisks - 1]) {
      error("You cannot place a larger disk on a smaller one");
   }
   towers[finish - 'A'].add(disk);
   repaintWindow();
   pause(delayTime);
}

/*
 * Function: setDelayTime
 * Usage: setDelayTime(msec);
 * --------------------------
 * Sets the number of milliseconds that the program pauses
 * after making a move.  Smaller numbers lead to faster
 * animations.  The default is 200 msec.
 */

void setDelayTime(double msec) {
   delayTime = msec;
}

/* Calculates various parameters for the drawing */

static void computeGraphicsParameters(int n) {
   frameThickness = FRAME_THICKNESS_PIXELS;
   diskHeight = DISK_HEIGHT_PIXELS;
   diskMax = DISK_MAX_PIXELS;
   diskDelta = DISK_DELTA_PIXELS;
   frameWidth = 0.9 * getWindowWidth();
   frameHeight = 2 * frameThickness + n * diskHeight;
   frameX[1] = getWindowWidth() / 2;
   frameX[0] = frameX[1] - frameWidth * 0.3;
   frameX[2] = frameX[1] + frameWidth * 0.3;
   xBase = 0.05 * getWindowWidth();
   yBase = (getWindowHeight() - cSign * frameHeight) / 2;
}

/* Erases and repaints the entire window. */

static void repaintWindow() {
   initGraphics();
   drawFrame();
   for (int i = 0; i < 3; i++) {
      for (int j = 0; j < towers[i].size(); j++) {
         drawDisk(towers[i][j], i, j);
      }
   }
}

/* Draws the frame */

static void drawFrame() {
   fillRect(xBase, yBase, frameWidth, frameThickness);
   for (int i = 0; i < 3; i++) {
      double x = frameX[i] - frameThickness / 2;
      fillRect(x, yBase - frameHeight, frameThickness, frameHeight);
   }
}

/* Draws disk k at the specified position */

static void drawDisk(int k, int tower, int level) {
   double diskWidth = diskMax - (MAX_DISKS - k) * diskDelta;
   double x = frameX[tower] - diskWidth / 2;
   double y = yBase - (level + 1) * diskHeight;
   setColor(COLOR_TABLE[k]);
   fillRect(x, y, diskWidth, diskHeight - 1);
   setColor("Black");
}
