/*
 * File: Hanoi.cpp
 * ---------------
 * This program solves the Tower of Hanoi puzzle.
 */

#include <iostream>
#include "HanoiGraphics.h"
#include "graphics.h"
using namespace std;

/* Function prototypes */

void moveTower(int n, char to, char from, char temp);

/* Main program */

int main() {
   int nDisks = 6;
   initHanoiGraphics(nDisks);
   moveTower(nDisks, 'A', 'C', 'B');
   return 0;
}


/*
 * Function: moveTower
 * Usage: moveTower(n, from, to, temp);
 * -----------------------------------------
 * Moves a tower of size n from the start spire to the finish
 * spire using the temp spire as the temporary repository.
 */
void moveTower(int n, char from, char to, char temp) {
	if (n != 0) {
		moveTower(n - 1, from, temp, to);
		moveSingleDisk(from, to);
		moveTower(n - 1, temp, to, from);
	}
}
